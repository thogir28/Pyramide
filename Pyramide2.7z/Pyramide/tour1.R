C1=data.frame(4)


for (i in 1:nb_play){
  p<-players[i]
  
  val<-tirage(cartes)
  cartes<-val[1:length(val)-1]
  C1[1,i]<-val[length(val)]
  
  couleur<-function(carte){
    mod<-carte%%4
    if (mod ==0 | mod==3){
      couleur<-"ROUGE"
    }else{
      couleur<-"NOIR"
    }
    return (couleur)
  }
  coul<-couleur(C1[1,i])
  coul_p=""
  while(coul_p!="ROUGE" & coul_p!="NOIR"){
    coul_p<-toupper(dlgInput(paste(p,", rouge ou noir ?"))$res)
  }
  
  
  display(readPNG(paste(chemin_img,C1[1,i],".png",sep="")))
  
  
  if (coul_p==coul){
    tkmessageBox(title = "Verdict",
                 message = "Tu donnes une gorgée !", icon = "info", type = "ok")
  }else{
    tkmessageBox(title = "Verdict",
                 message = "Tu bois !", icon = "info", type = "ok")
  }
  
  ok=""
  while(ok!="Y"){
    ok<-toupper(dlgInput(paste(p,"as-tu vu ta première carte ?"))$res)
  }
  
}


colnames(C1)<-players