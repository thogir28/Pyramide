library(shiny)

# Define UI for miles per gallon application
shinyUI(pageWithSidebar(
  
  # Application title
  headerPanel("Pyramide"),
  
  sidebarPanel(
    selectInput("p", "Joueur n° :",
                list('1'=1,
                     '2'=2,
                     '3'=3,
                     '4'=4)),
    
    selectInput("n", "Cartes :", 
                list("Première carte"=1,
                     "Seconde carte"=2,
                     "Troisième carte"=3,
                     "Quatrième carte"=4))
      
  ),
  
  mainPanel(
    textOutput("text1"),
    imageOutput("preImage"))
))

