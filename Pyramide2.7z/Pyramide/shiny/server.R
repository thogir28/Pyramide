library(shiny)
library(png)
library(tcltk2)
library(gtools)
library(svDialogs)
library(imager)

#plot(load.image(paste(chemin_img,C1[1,i],".png",sep="")))




# Define server logic required to plot various variables against mpg
# shinyServer(function(input, output) {
#   
#   formulaText <- reactive({
#     paste("mpg ~", input$Cartes)
#  })
#  
#  carte_plot<-paste(chemin_img,C1[1:input$Cartes],".png",sep="")
#  
#  output$mpgmyimage<-renderImage({
#    outfile<-tempfile(fileext=paste(chemin_img,"temp.png",sep=""))
#    png(outfile,widtf=400, height=300)
#    plot(load.image(carte_plot))
#    
#  })
#    
#  
#})
#

deck<-1:52
chemin_img<-"//grenade/dev_sem$/_131_ThomasG/Autres/test/intro_SAS/cards/"


# Define server logic required to plot various variables against mpg
shinyServer(function(input, output) {
#  
#  carte_plot <- reactive({
#       
#    plot(load.image(paste(chemin_img,2,".png",sep="")))
#   })
#  
#  output$myimage<-renderPlot({
#    plot(carte_plot())
#    
#  })
#  
#})

  output$text1 <- renderText({ 
    paste(players[as.numeric(input$p)])
  })

  
  
    # Send a pre-rendered image, and don't delete the image after sending it
    output$preImage <- renderImage({
      # When input$n is 3, filename is ./images/image3.jpeg
      filename <- normalizePath(file.path(paste('//grenade/dev_sem$/_131_ThomasG/Autres/test/intro_SAS/cards/',C1[input$n,as.numeric(input$p)],'.png', sep='')))
      
      # Return a list containing the filename and alt text
      list(src = filename,
           alt = paste("Image number", input$n))
      
    }, deleteFile = FALSE)
  })


