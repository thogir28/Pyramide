
val3=data.frame()

for (i in 1:nb_play){
  p<-players[i]
  
  #plot(load.image(paste(chemin_img,C1[1,i],".png",sep="")))
  
  #ok=""
  #while(ok!="YES"){
  #  ok<-toupper(dlgInput(paste(p,"as-tu vu ta première carte ?"))$res)
  #}
  
  #plot(load.image(paste(chemin_img,C1[2,i],".png",sep="")))
  
  #ok=""
  #while(ok!="YES"){
  #  ok<-toupper(dlgInput(paste(p,"as-tu vu ta seconde carte ?"))$res)
  #}
  
  
  val<-tirage(cartes)
  cartes<-val[1:length(val)-1]
  C1[3,i]<-val[length(val)]
  
  
  
  if (C1[3,i]%%4==0){
    val3[1,i]<-C1[3,i]
  }else if (C1[3,i]%%4==1){
    val3[1,i]<-C1[3,i]+3
  } else if (C1[3,i]%%4==2){
    val3[1,i]<-C1[3,i]+2
  } else if (C1[3,i]%%4==3){
    val3[1,i]<-C1[3,i]+1
  }
  
  
  if((val3[1,i]<val2[1,i] & val3[1,i]>val1[1,i]) | (val3[1,i]>val2[1,i] & val3[1,i]<val1[1,i])) {
    intext<-"INT"
  }else if(val3[1,i]==val2[1,i] | val3[1,i]==val1[1,i]){
    intext="EGA"
  }else{
    intext="EXT"
  }
  
  
  
  intext_p=""
  while(intext_p!="EXT" & intext_p!="INT" & intext_p!="EGA"){
    intext_p<-toupper(dlgInput(paste(p,", intérieur ou extérieur (ou égalité :P ) ?"))$res)
  }
  
  plot(load.image(paste(chemin_img,C1[3,i],".png",sep="")))
  
  if (intext_p==intext){
    tkmessageBox(title = "Verdict",
                 message = "Tu donnes 3 gorgées !", icon = "info", type = "ok")
  }else{
    tkmessageBox(title = "Verdict",
                 message = "Tu bois 3 gorgées !", icon = "info", type = "ok")
  }
  
  ok=""
  while(ok!="Y"){
    ok<-toupper(dlgInput(paste(p,"as-tu vu ta troisième carte ?"))$res)
  }
}
