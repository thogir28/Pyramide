
# Programme Pyramide
# Author : Thomas Giraud
# Date : 02/06/2017
#

rm(list=ls())

#chemin vers le dossier d'image
chemin_img<-"//grenade/dev_sem$/_131_ThomasG/Autres/test/intro_SAS/cards/"

#chemin vers le dossier de scripts de la Pyramide 
chemin_scripts<-"//grenade/dev_sem$/_131_ThomasG/Autres/test/Pyramide/"


#appel du programme d'installation des packages (pour la 1ere utilisation)

#source(paste(chemin_scripts,"install_packages.R",sep=""))


library(png)
library(tcltk2)
library(gtools)
library(svDialogs)
library(imager)


#appel du programme où sont stockées des fonctions
source(paste(chemin_scripts,"display.R",sep=""))


#on génère le jeu de 52 cartes
cartes<-1:52

#on définie les joueurs 
players<-function(){
  play<-character()

  i<-1
  while(i<100){
    play[i]<-dlgInput(paste("Prénom du joueur",i))$res
    print(play[i])
    if (play[i]==""){
      i<-100
    }
    i<-i+1
  }
  play<-subset(play,play!="")
  return(play)
}


players<-players()
nb_play<-length(players)


#tour1 

source(paste(chemin_scripts,"tour1.R",sep=""), encoding="UTF-8")

runApp(paste(chemin_scripts,"shiny/",sep=""))

#tour2

source(paste(chemin_scripts,"tour2.R",sep=""), encoding="UTF-8")

runApp(paste(chemin_scripts,"shiny/",sep=""))

#tour3

source(paste(chemin_scripts,"tour3.R",sep=""), encoding="UTF-8")

runApp(paste(chemin_scripts,"shiny/",sep=""))

#tour4

source(paste(chemin_scripts,"tour4.R",sep=""), encoding="UTF-8")

runApp(paste(chemin_scripts,"shiny/",sep=""))
