
val4=data.frame()

for (i in 1:nb_play){
  p<-players[i]
  
  val<-tirage(cartes)
  cartes<-val[1:length(val)-1]
  C1[4,i]<-val[length(val)]
  
  if (C1[4,i]%%4==1){
    forme<-"TREFLE"
  } else if (C1[4,i]%%4==2){
    forme<-"PIQUE"
  } else if (C1[4,i]%%4==3){
    forme<-"COEUR"
  } else{
    forme<-"CARREAU"
  }
  
  forme_p=""
  while(forme_p!="TREFLE" & forme_p!="PIQUE" & forme_p!="COEUR" & forme_p!="CARREAU"){
    forme_p<-toupper(dlgInput(paste(p,", quelle forme ? Carreau, pique, trefle, coeur ?"))$res)
  }
  
  plot(load.image(paste(chemin_img,C1[4,i],".png",sep="")))
  
  if (forme_p==forme){
    tkmessageBox(title = "Verdict",
                 message = "Tu donnes 4 gorgées !", icon = "info", type = "ok")
  }else{
    tkmessageBox(title = "Verdict",
                 message = "Tu bois 4 gorgées !", icon = "info", type = "ok")
  }
  
  ok=""
  while(ok!="Y"){
    ok<-toupper(dlgInput(paste(p,"as-tu vu ta quatrième carte ?"))$res)
  }
}