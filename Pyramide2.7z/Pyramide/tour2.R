val1<-data.frame()
val2<-data.frame()

for (i in 1:nb_play){
  p<-players[i]
  
  #plot(load.image(paste(chemin_img,C1[1,i],".png",sep="")))
  
  
  #ok=""
  #while(ok!="YES"){
  #  ok<-toupper(dlgInput(paste(p,"as-tu vu ta première carte ?"))$res)
  #}
  
  val<-tirage(cartes)
  cartes<-val[1:length(val)-1]
  C1[2,i]<-val[length(val)]
  
  
  
  if (C1[1,i]%%4==0){
    val1[1,i]<-C1[1,i]
  }else if (C1[1,i]%%4==1){
    val1[1,i]<-C1[1,i]+3
  } else if (C1[1,i]%%4==2){
    val1[1,i]<-C1[1,i]+2
  } else if (C1[1,i]%%4==3){
    val1[1,i]<-C1[1,i]+1
  }
  
  if (C1[2,i]%%4==0){
    val2[1,i]<-C1[2,i]
  }else if (C1[2,i]%%4==1){
    val2[1,i]<-C1[2,i]+3
  } else if (C1[2,i]%%4==2){
    val2[1,i]<-C1[2,i]+2
  } else if (C1[2,i]%%4==3){
    val2[1,i]<-C1[2,i]+1
  }
  
  if (val2[1,i]>val1[1,i]) {
    supinf<-"SUP"
  }else if (val2[1,i]<val1[1,i]){
    supinf<-"INF"
  }else{
    supinf<-"EGA"
  }
  
  supinf_p=""
  while(supinf_p!="SUP" & supinf_p!="INF"){
    supinf_p<-toupper(dlgInput(paste(p,", sup ou inf (ou ega !) ?"))$res)
  }
  
  plot(load.image(paste(chemin_img,C1[2,i],".png",sep="")))
  
  if (supinf_p==supinf){
    tkmessageBox(title = "Verdict",
                 message = "Tu donnes 2 gorgées !", icon = "info", type = "ok")
  }else{
    tkmessageBox(title = "Verdict",
                 message = "Tu bois 2 gorgées !", icon = "info", type = "ok")
  }
  
  ok=""
  while(ok!="Y"){
    ok<-toupper(dlgInput(paste(p,"as-tu vu ta seconde carte ?"))$res)
  }
}